import * as vscode from 'vscode';
import * as dotenv from 'dotenv';
import { GoogleGenerativeAI } from '@google/generative-ai';
const path = require('path');
import * as fs from 'fs';

dotenv.config({
  // one folder back is .env
  path: path.join(__dirname, '../.env'),
});

const apiKey = process.env.API_KEY;

export function activate(context: vscode.ExtensionContext) {
  if (!apiKey) {
    throw new Error('API_KEY is not set in the environment variables');
  }

  // Add code to handle username and password login

  vscode.window.showInputBox({
    prompt: 'Enter your username',
    ignoreFocusOut: true,
  }).then((username) => {
    if (!username) {
      return;
    }

    vscode.window.showInputBox({
      prompt: 'Enter your password',
      password: true,
      ignoreFocusOut: true,
    }).then((password) => {
      if (!password) {
        return;
      }


      const genAI = new GoogleGenerativeAI(apiKey);
      let rawdata = fs.readFileSync('C:/Users/pranav/Vscode Extension/gemini_extension/codegenerator/src/db/users.json', 'utf8');
      let users = JSON.parse(rawdata);
      users = users.user_details;
      // Check if the username and password is in .json file
      let row = false;
      users.forEach((element: { username: string; password: string; }) => {
        if (element.username === username && element.password === password) {
          row = true;
        }
      }
      );
        // If the username and password are correct, show the chat interface
        if (row) {
          const panel = vscode.window.createWebviewPanel(
            'Dasamukha', // Identifies the webview panel
            'Dasamukha Bot', // Title of the panel
            vscode.ViewColumn.Active, // Display the panel in the active editor group
            {
              enableScripts: true, // Allow scripts to run in the webview
              retainContextWhenHidden: true, // Keep the webview's state when it's hidden
            }
          );
          const htmlContent = `
            <!DOCTYPE html>
            <html>
              <head>
                <meta charset="UTF-8" />
                <title>Gemini Chat</title>
                <style>
                  body {
                    margin: 0;
                    padding: 0;
                    font-family: sans-serif;
                  }

                  #chat-container {
                    display: flex;
                    flex-direction: column;
                    height: 100vh;
                  }

                  #chat-input {
                    width: 100%;
                    padding: 10px;
                    margin-bottom: 10px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                  }

                  #chat-messages {
                    flex: 1;
                    overflow-y: auto;
                  }

                  .message {
                    padding: 10px;
                    margin-bottom: 10px;
                    border-radius: 5px;
                  }

                  .user-message {
                    background-color: #efefef;
                    align-self: flex-end;
                  }

                  .ai-message {
                    background-color: #000;
                    color: #fff;
                    align-self: flex-start;
                  }
                </style>
              </head>
              <body>
                <div id="chat-container">
                  <input id="chat-input" placeholder="Ask your question here..." />
                  <div id="chat-messages"></div>
                </div>
                <script>
                  const vscode = acquireVsCodeApi();

                  // Handle the user's input
                  const input = document.getElementById('chat-input');
                  input.addEventListener('keydown', (event) => {
                    if (event.key === 'Enter') {
                      // Send the user's prompt to the extension's main code
                      vscode.postMessage({
                        type: 'new_prompt',
                        prompt: input.value,
                      });

                      // Clear the input field
                      input.value = '';
                    }
                  });

                  // Handle incoming messages from the extension's main code
                  window.addEventListener('message', (event) => {
                    const message = event.data;

                    if (message.type === 'new_response') {
                      // Display the AI's response in the chat interface
                      const messages = document.getElementById('chat-messages');
                      const messageElement = document.createElement('div');
                      messageElement.classList.add('message', 'ai-message');
                      messageElement.textContent = message.response;
                      messages.appendChild(messageElement);

                      // Scroll to the bottom of the chat messages
                      messages.scrollTop = messages.scrollHeight;
                    }
                  });
                </script>
              </body>
            </html>
          `;
          panel.webview.html = htmlContent;

          // Handle messages received from the webview panel
          panel.webview.onDidReceiveMessage(async (message) => {
            switch (message.type) {
              case 'new_prompt':
                // Generate text using the Generative AI API
                const prompt = message.prompt;
                const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
                const result = await model.generateContent(prompt);
                const response = await result.response;
                const text = response.text();

                // Convert the response to upside/downside format
                const formattedResponse = text.replace(/Downside/g, 'Upside').replace(/upside/g, 'downside');

                // Send the generated text back to the webview panel
                panel.webview.postMessage({
                  type: 'new_response',
                  response: formattedResponse,
                });
                break;
            }
          });

          // Clean up when the panel is closed
          panel.onDidDispose(() => {
            // Dispose of the panel's resources
          });
        } else {
          vscode.window.showErrorMessage('Invalid username or password');
        }
    }
    );
  }
  );
}

export function deactivate() {
  // Clean up when the extension is deactivated
}