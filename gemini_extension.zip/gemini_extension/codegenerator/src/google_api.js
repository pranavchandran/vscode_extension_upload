
// const dotenv = require('dotenv');
// const path = require('path');

// dotenv.config({
// 	// one folder back is .env
//     path: path.join(__dirname, '../.env')
// });
// console.log(__dirname);
// let apiKey = process.env.API_KEY;
// console.log(apiKey);
// const { GoogleGenerativeAI } = require('@google/generative-ai');

// dotenv.config({ path: path.join(__dirname, '.env') });

// const apiKey = process.env.API_KEY;

// if (!apiKey) {
//     throw new Error('API_KEY is not set in the environment variables');
// }

// const genAI = new GoogleGenerativeAI(apiKey);

// async function test() {
//     const model = genAI.getGenerativeModel({ model: "gemini-pro"});
//     const prompt = "Write a story about a magic backpack.";
//     const result = await model.generateContent(prompt);
//     const response = await result.response;
//     const text = response.text();
//     console.log(text);
// }

// test().catch(console.error);

// check db is working or not
// const sqlite3 = require('sqlite3').verbose();
// const fs = require('fs');

// // open the database
// let db = new sqlite3.Database('./db/users_details.db', (err) => {
//     if (err) {
//         console.error(err.message);
//     }
//     console.log('Connected to the database.');
//     db.get("SELECT * FROM users_details", (err, row) => {
//         if (err) {
//             console.error(err.message);
//         }
//         console.log(row);
//     });
// });

//json file read
const fs = require('fs');

let rawdata = fs.readFileSync('C:/Users/pranav/Vscode Extension/gemini_extension/codegenerator/src/db/users.json');
let users = JSON.parse(rawdata);
users = users.user_details;
let user = 'Pranav';
let password = '1234';
// console.log(users);
// Find user and password
let found = false;
users.forEach((element) => {

    if (element.username == user && element.password == password) {
        console.log(element);
    }
});